package main

import (
	"log"
	"net"
	"net/http"
	"strings"

	"github.com/seiki/2fa-backend/internal/config"
	"github.com/seiki/2fa-backend/internal/datafile"
	"github.com/seiki/2fa-backend/internal/handler"
	"github.com/seiki/2fa-backend/internal/middleware"
)

func main() {
	cfg := config.Load()

	data := datafile.New(cfg.DataFile)
	h := handler.New(data)
	auth := middleware.APIKey(cfg.APIKey)

	accessLog, err := middleware.NewAccessLogger(cfg.AccessLogFile)
	if err != nil {
		log.Fatalf("init access logger: %v", err)
	}
	defer accessLog.Close()

	mux := http.NewServeMux()

	// health (frontend: test connection)
	mux.Handle("GET /api/health", auth(http.HandlerFunc(h.Health)))
	mux.Handle("GET /health", auth(http.HandlerFunc(h.Health)))
	mux.Handle("GET /", auth(http.HandlerFunc(h.Root)))

	// accounts backup API (aligned with frontend)
	mux.Handle("GET /api/2fa/accounts", auth(http.HandlerFunc(h.GetAccounts)))
	mux.Handle("PUT /api/2fa/accounts", auth(http.HandlerFunc(h.PutAccounts)))
	mux.Handle("POST /api/2fa/accounts", auth(http.HandlerFunc(h.PutAccounts)))

	// legacy read paths
	mux.Handle("GET /api/2fa", auth(http.HandlerFunc(h.GetAccounts)))
	mux.Handle("GET /2fa/accounts", auth(http.HandlerFunc(h.GetAccounts)))

	server := &http.Server{
		Addr:    cfg.Addr,
		Handler: accessLog.Middleware(middleware.CORS(mux)),
	}

	port := strings.TrimPrefix(cfg.Addr, ":")
	ip := localIPv4()
	log.Println("========================================")
	log.Printf("服务器地址: http://%s:%s", ip, port)
	log.Printf("本地访问:   http://127.0.0.1:%s", port)
	log.Printf("API Key:    %s", cfg.APIKey)
	log.Printf("接口日志:   %s", cfg.AccessLogFile)
	log.Println("========================================")
	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Fatalf("server error: %v", err)
	}
}

func localIPv4() string {
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		return "127.0.0.1"
	}
	for _, addr := range addrs {
		ipnet, ok := addr.(*net.IPNet)
		if !ok || ipnet.IP.IsLoopback() {
			continue
		}
		if ip := ipnet.IP.To4(); ip != nil {
			return ip.String()
		}
	}
	return "127.0.0.1"
}
