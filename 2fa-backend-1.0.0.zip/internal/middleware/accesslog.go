package middleware

import (
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"time"
)

type AccessLogger struct {
	logger *log.Logger
	file   *os.File
}

func NewAccessLogger(path string) (*AccessLogger, error) {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return nil, err
	}

	f, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o644)
	if err != nil {
		return nil, err
	}

	return &AccessLogger{
		file:   f,
		logger: log.New(io.MultiWriter(f, os.Stdout), "", 0),
	}, nil
}

func (a *AccessLogger) Close() error {
	if a.file != nil {
		return a.file.Close()
	}
	return nil
}

func (a *AccessLogger) Middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		rw := &responseWriter{ResponseWriter: w, status: http.StatusOK}
		next.ServeHTTP(rw, r)

		a.logger.Printf(
			`[%s] %s %s %s %d %s "%s"`,
			start.Format("2006-01-02 15:04:05"),
			clientIP(r),
			r.Method,
			r.URL.Path,
			rw.status,
			time.Since(start).Round(time.Millisecond),
			r.UserAgent(),
		)
	})
}

type responseWriter struct {
	http.ResponseWriter
	status int
}

func (rw *responseWriter) WriteHeader(code int) {
	rw.status = code
	rw.ResponseWriter.WriteHeader(code)
}

func clientIP(r *http.Request) string {
	if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
		return xff
	}
	if xri := r.Header.Get("X-Real-IP"); xri != "" {
		return xri
	}
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return host
}
