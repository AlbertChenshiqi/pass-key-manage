package model

type Account struct {
	ID         string `json:"id"`
	Type       string `json:"type,omitempty"` // totp, login, note, card, identity
	Name       string `json:"name"`
	Secret     string `json:"secret,omitempty"`
	OtpauthURL string `json:"otpauthUrl,omitempty"`
	URL        string `json:"url,omitempty"`
	Username   string `json:"username,omitempty"`
	Password   string `json:"password,omitempty"`
	Notes      string `json:"notes,omitempty"`
	Cardholder string `json:"cardholder,omitempty"`
	Number     string `json:"number,omitempty"`
	Expiry     string `json:"expiry,omitempty"`
	CVV        string `json:"cvv,omitempty"`
	FullName   string `json:"fullName,omitempty"`
	Email      string `json:"email,omitempty"`
	Phone      string `json:"phone,omitempty"`
	Address    string `json:"address,omitempty"`
	CreatedAt  int64  `json:"createdAt"`
}

type Payload struct {
	Version     int       `json:"version"`
	ExportedAt  int64     `json:"exportedAt"`
	NextVaultID int64     `json:"nextVaultId,omitempty"`
	Accounts    []Account `json:"accounts"`
}

type HealthResponse struct {
	Status string `json:"status"`
}

type ErrorResponse struct {
	Error string `json:"error"`
}
