package config

import (
	"os"
)

type Config struct {
	Addr          string
	APIKey        string
	DataFile      string
	AccessLogFile string
}

func Load() Config {
	port := getenv("PORT", "25100")
	return Config{
		Addr:          ":" + port,
		APIKey:        getenv("API_KEY", "dev-api-key"),
		DataFile:      getenv("DATA_FILE", "./data/data.json"),
		AccessLogFile: getenv("ACCESS_LOG_FILE", "./logs/access.log"),
	}
}

func getenv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}
