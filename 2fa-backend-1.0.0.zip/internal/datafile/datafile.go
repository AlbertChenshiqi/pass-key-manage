package datafile

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sync"
	"time"

	"github.com/seiki/2fa-backend/internal/model"
)

// File 直接读写 data.json，不做内存缓存；每次请求从磁盘读取最新数据。
type File struct {
	path string
	mu   sync.Mutex
}

func New(path string) *File {
	return &File{path: path}
}

func (f *File) Read() (model.Payload, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	return readFromDisk(f.path)
}

func (f *File) Write(payload model.Payload) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	return writeToDisk(f.path, payload)
}

func readFromDisk(path string) (model.Payload, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			empty := model.Payload{
				Version:    1,
				ExportedAt: time.Now().UnixMilli(),
				Accounts:   []model.Account{},
			}
			if err := writeToDisk(path, empty); err != nil {
				return model.Payload{}, err
			}
			return empty, nil
		}
		return model.Payload{}, err
	}

	var payload model.Payload
	if err := json.Unmarshal(raw, &payload); err != nil {
		return model.Payload{}, err
	}
	if payload.Accounts == nil {
		payload.Accounts = []model.Account{}
	}
	if payload.Version == 0 {
		payload.Version = 1
	}
	return payload, nil
}

func writeToDisk(path string, payload model.Payload) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	if payload.Accounts == nil {
		payload.Accounts = []model.Account{}
	}
	if payload.Version == 0 {
		payload.Version = 1
	}
	payload.ExportedAt = time.Now().UnixMilli()

	raw, err := json.MarshalIndent(payload, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, raw, 0o600)
}
