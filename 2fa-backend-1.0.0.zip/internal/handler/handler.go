package handler

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"github.com/seiki/2fa-backend/internal/datafile"
	"github.com/seiki/2fa-backend/internal/model"
)

type Handler struct {
	data *datafile.File
}

func New(data *datafile.File) *Handler {
	return &Handler{data: data}
}

func (h *Handler) Health(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, model.HealthResponse{Status: "ok"})
}

func (h *Handler) Root(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, model.HealthResponse{Status: "ok"})
}

func (h *Handler) GetAccounts(w http.ResponseWriter, _ *http.Request) {
	payload, err := h.data.Read()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, model.ErrorResponse{Error: "read data failed"})
		return
	}
	writeJSON(w, http.StatusOK, payload)
}

func (h *Handler) PutAccounts(w http.ResponseWriter, r *http.Request) {
	body, err := io.ReadAll(io.LimitReader(r.Body, 1<<20))
	if err != nil {
		writeJSON(w, http.StatusBadRequest, model.ErrorResponse{Error: "read body failed"})
		return
	}

	payload, err := parseBackupPayload(body)
	if err != nil {
		writeJSON(w, http.StatusBadRequest, model.ErrorResponse{Error: err.Error()})
		return
	}

	if err := h.data.Write(payload); err != nil {
		writeJSON(w, http.StatusInternalServerError, model.ErrorResponse{Error: "save failed"})
		return
	}

	saved, err := h.data.Read()
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, model.ErrorResponse{Error: "read data failed"})
		return
	}
	writeJSON(w, http.StatusOK, saved)
}

func parseBackupPayload(body []byte) (model.Payload, error) {
	var payload model.Payload
	if err := json.Unmarshal(body, &payload); err != nil {
		var accounts []model.Account
		if err2 := json.Unmarshal(body, &accounts); err2 != nil {
			return model.Payload{}, errors.New("invalid json payload")
		}
		payload.Accounts = accounts
	}

	if len(payload.Accounts) == 0 {
		return model.Payload{}, errors.New("accounts is empty")
	}

	for i, acc := range payload.Accounts {
		acc = normalizeAccount(acc)
		if acc.ID == "" || acc.Name == "" {
			return model.Payload{}, fmt.Errorf("accounts[%d] id and name are required", i)
		}
		if err := validateAccount(acc, i); err != nil {
			return model.Payload{}, err
		}
		payload.Accounts[i] = acc
	}

	if payload.Version == 0 {
		payload.Version = 1
	}
	payload.ExportedAt = time.Now().UnixMilli()
	return payload, nil
}

func normalizeAccount(acc model.Account) model.Account {
	acc.ID = strings.TrimSpace(acc.ID)
	acc.Name = strings.TrimSpace(acc.Name)
	acc.Type = strings.TrimSpace(acc.Type)
	acc.Secret = strings.TrimSpace(acc.Secret)
	acc.OtpauthURL = strings.TrimSpace(acc.OtpauthURL)
	acc.URL = strings.TrimSpace(acc.URL)
	acc.Username = strings.TrimSpace(acc.Username)
	acc.Password = strings.TrimSpace(acc.Password)
	acc.Notes = strings.TrimSpace(acc.Notes)
	acc.Cardholder = strings.TrimSpace(acc.Cardholder)
	acc.Number = strings.TrimSpace(acc.Number)
	acc.Expiry = strings.TrimSpace(acc.Expiry)
	acc.CVV = strings.TrimSpace(acc.CVV)
	acc.FullName = strings.TrimSpace(acc.FullName)
	acc.Email = strings.TrimSpace(acc.Email)
	acc.Phone = strings.TrimSpace(acc.Phone)
	acc.Address = strings.TrimSpace(acc.Address)

	if acc.Type == "" {
		switch {
		case acc.Secret != "" || acc.OtpauthURL != "":
			acc.Type = "totp"
		case acc.Username != "" || acc.Password != "" || acc.URL != "":
			acc.Type = "login"
		case acc.Number != "" || acc.Cardholder != "":
			acc.Type = "card"
		case acc.FullName != "" || acc.Email != "" || acc.Phone != "":
			acc.Type = "identity"
		default:
			acc.Type = "note"
		}
	}
	return acc
}

func validateAccount(acc model.Account, i int) error {
	switch acc.Type {
	case "totp":
		if acc.Secret == "" && acc.OtpauthURL == "" {
			return fmt.Errorf("accounts[%d] secret or otpauthUrl is required", i)
		}
	case "login":
		if acc.Username == "" && acc.Password == "" {
			return fmt.Errorf("accounts[%d] username or password is required", i)
		}
	case "note":
		if acc.Notes == "" {
			return fmt.Errorf("accounts[%d] notes is required", i)
		}
	case "card":
		if acc.Cardholder == "" && acc.Number == "" {
			return fmt.Errorf("accounts[%d] cardholder or number is required", i)
		}
	case "identity":
		if acc.FullName == "" && acc.Email == "" && acc.Phone == "" {
			return fmt.Errorf("accounts[%d] at least one identity field is required", i)
		}
	default:
		return fmt.Errorf("accounts[%d] unsupported type: %s", i, acc.Type)
	}
	return nil
}

func writeJSON(w http.ResponseWriter, status int, body any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(body)
}
