module github.com/seiki/2fa-backend

go 1.22
