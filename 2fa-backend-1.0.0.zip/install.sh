#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# ---------- 可配置 ----------
# 完整 zip 地址（优先级最高，适合 Release 包）
GIT_ZIP_URL="${GIT_ZIP_URL:-}"
# 或指定仓库与分支，从 GitHub 拉取源码归档
GIT_REPO="${GIT_REPO:-https://github.com/seiki/2fa}"
GIT_REF="${GIT_REF:-main}"
# 仓库为 monorepo 时，服务端子目录
GIT_SUBDIR="${GIT_SUBDIR:-backend}"
# 安装目录（远程拉取时使用）
INSTALL_DIR="${INSTALL_DIR:-${HOME}/2fa-backend}"
# 设为 1 强制从 zip 重新下载（即使本地已有源码）
USE_GIT_ZIP="${USE_GIT_ZIP:-0}"

DEFAULT_PORT="25100"
ENV_FILE=".env"
BIN_FILE="bin/server"
PID_FILE="bin/server.pid"
LOG_DIR="logs"
INSTALL_LOG="${LOG_DIR}/install.log"
SERVER_LOG="${LOG_DIR}/server.log"
ACCESS_LOG="${LOG_DIR}/access.log"

need_cmd() {
  if ! command -v "$1" &>/dev/null; then
    echo "错误: 未找到命令 $1"
    exit 1
  fi
}

get_local_ip() {
  if command -v ip &>/dev/null; then
    ip -4 route get 1.1.1.1 2>/dev/null | awk '{print $7; exit}'
  elif [[ "$(uname -s)" == "Darwin" ]]; then
    ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || echo "127.0.0.1"
  else
    hostname -I 2>/dev/null | awk '{print $1}'
  fi
}

resolve_install_root() {
  if [[ -f "$SCRIPT_DIR/go.mod" ]] && [[ "$USE_GIT_ZIP" != "1" ]]; then
    INSTALL_ROOT="$SCRIPT_DIR"
    return
  fi
  INSTALL_ROOT="$INSTALL_DIR"
}

download_zip() {
  local url="$1"
  local dest="$2"
  echo ">> 下载: $url"
  if command -v curl &>/dev/null; then
    curl -fsSL "$url" -o "$dest"
  elif command -v wget &>/dev/null; then
    wget -qO "$dest" "$url"
  else
    echo "错误: 需要 curl 或 wget"
    exit 1
  fi
}

extract_source_from_zip() {
  local zip_file="$1"
  local out_dir="$2"
  local tmp_dir
  tmp_dir="$(mktemp -d)"

  echo ">> 解压安装包..."
  unzip -q "$zip_file" -d "$tmp_dir"

  local extracted src_dir=""
  extracted="$(find "$tmp_dir" -mindepth 1 -maxdepth 1 -type d | head -1)"

  if [[ -f "$extracted/go.mod" ]]; then
    src_dir="$extracted"
  elif [[ -n "$GIT_SUBDIR" && -f "$extracted/${GIT_SUBDIR}/go.mod" ]]; then
    src_dir="$extracted/${GIT_SUBDIR}"
  else
    src_dir="$(find "$tmp_dir" -name go.mod -print -quit | xargs dirname 2>/dev/null || true)"
  fi

  if [[ -z "$src_dir" || ! -f "$src_dir/go.mod" ]]; then
    echo "错误: zip 中未找到服务端源码 (go.mod)"
    rm -rf "$tmp_dir"
    exit 1
  fi

  mkdir -p "$out_dir"
  # 保留 data、.env、logs、bin（若已存在）
  if [[ -d "$out_dir/data" ]]; then
    cp -a "$out_dir/data" "$tmp_dir/_keep_data"
  fi
  if [[ -f "$out_dir/.env" ]]; then
    cp -a "$out_dir/.env" "$tmp_dir/_keep_env"
  fi
  if [[ -d "$out_dir/logs" ]]; then
    mkdir -p "$tmp_dir/_keep_logs"
    cp -a "$out_dir/logs/." "$tmp_dir/_keep_logs/" 2>/dev/null || true
  fi

  rm -rf "$out_dir"
  mkdir -p "$out_dir"
  cp -a "$src_dir/." "$out_dir/"

  if [[ -d "$tmp_dir/_keep_data" ]]; then
    mkdir -p "$out_dir/data"
    cp -a "$tmp_dir/_keep_data/." "$out_dir/data/"
  fi
  if [[ -f "$tmp_dir/_keep_env" ]]; then
    cp -a "$tmp_dir/_keep_env" "$out_dir/.env"
  fi
  if [[ -d "$tmp_dir/_keep_logs" ]]; then
    mkdir -p "$out_dir/logs"
    cp -a "$tmp_dir/_keep_logs/." "$out_dir/logs/" 2>/dev/null || true
  fi

  rm -rf "$tmp_dir"
  echo ">> 已安装到: $out_dir"
}

fetch_and_install() {
  need_cmd unzip

  local zip_url="${GIT_ZIP_URL}"
  if [[ -z "$zip_url" ]]; then
  zip_url="${GIT_REPO%/}/archive/refs/heads/${GIT_REF}.zip"
  fi

  local tmp_zip
  tmp_zip="$(mktemp /tmp/2fa-backend.XXXXXX.zip)"
  trap 'rm -f "$tmp_zip"' RETURN

  download_zip "$zip_url" "$tmp_zip"
  extract_source_from_zip "$tmp_zip" "$INSTALL_ROOT"
}

resolve_install_root

if [[ "$INSTALL_ROOT" != "$SCRIPT_DIR" ]] || [[ "$USE_GIT_ZIP" == "1" ]]; then
  fetch_and_install
fi

cd "$INSTALL_ROOT"
mkdir -p "$LOG_DIR" bin data
exec > >(tee -a "$INSTALL_LOG") 2>&1

echo ">> [$(date '+%Y-%m-%d %H:%M:%S')] install.sh 开始执行"
echo ">> 安装目录: ${INSTALL_ROOT}"
echo ">> 安装日志: ${INSTALL_ROOT}/${INSTALL_LOG}"

need_cmd go

load_env() {
  if [[ -f "$ENV_FILE" ]]; then
    # shellcheck disable=SC1090
    set -a
    source "$ENV_FILE"
    set +a
  fi
  PORT="${PORT:-$DEFAULT_PORT}"
}

is_configured() {
  [[ -f "$ENV_FILE" ]] && grep -q '^API_KEY=' "$ENV_FILE"
}

is_running() {
  load_env
  if command -v lsof &>/dev/null && lsof -ti ":${PORT}" &>/dev/null; then
    return 0
  fi
  if [[ -f "$PID_FILE" ]]; then
    local pid
    pid="$(cat "$PID_FILE")"
    if kill -0 "$pid" 2>/dev/null; then
      return 0
    fi
    rm -f "$PID_FILE"
  fi
  return 1
}

print_info() {
  load_env
  local ip
  ip="$(get_local_ip)"

  echo ""
  echo "========================================"
  echo "2FA 后端服务"
  echo "========================================"
  echo "服务器地址: http://${ip}:${PORT}"
  echo "本地访问:   http://127.0.0.1:${PORT}"
  echo "API Key:    ${API_KEY}"
  echo "运行日志:   ${INSTALL_ROOT}/${SERVER_LOG}"
  echo "接口日志:   ${INSTALL_ROOT}/${ACCESS_LOG}"
  echo "安装日志:   ${INSTALL_ROOT}/${INSTALL_LOG}"
  echo "========================================"
  echo ""
}

build_server() {
  echo ">> 下载依赖并编译..."
  go mod tidy
  go build -o "$BIN_FILE" .
}

first_install() {
  echo ">> 首次安装，生成 API Key..."

  API_KEY="$(openssl rand -hex 16)"
  cat > "$ENV_FILE" <<EOF
PORT=${DEFAULT_PORT}
API_KEY=${API_KEY}
DATA_FILE=./data/data.json
ACCESS_LOG_FILE=./logs/access.log
EOF

  build_server
  echo ">> 安装完成"
}

ensure_binary() {
  if [[ ! -x "$BIN_FILE" ]]; then
    echo ">> 未找到可执行文件，重新编译..."
    build_server
  fi
}

start_server() {
  load_env
  ensure_binary

  if is_running; then
    print_info
    echo "服务已在运行 (端口 ${PORT})"
    echo "查看运行日志: tail -f ${INSTALL_ROOT}/${SERVER_LOG}"
    echo "查看接口日志: tail -f ${INSTALL_ROOT}/${ACCESS_LOG}"
    exit 0
  fi

  print_info
  echo ">> 启动服务 (端口 ${PORT})..."
  echo ">> 运行日志写入: ${INSTALL_ROOT}/${SERVER_LOG}"
  echo ""

  nohup env PORT="$PORT" API_KEY="$API_KEY" DATA_FILE="${DATA_FILE:-./data/data.json}" \
    ACCESS_LOG_FILE="${ACCESS_LOG_FILE:-./logs/access.log}" \
    ./bin/server >> "$SERVER_LOG" 2>&1 &
  echo $! > "$PID_FILE"
  sleep 0.5

  if is_running; then
    echo "服务已启动"
    echo "运行日志: ${INSTALL_ROOT}/${SERVER_LOG}"
    echo "查看日志: tail -f ${INSTALL_ROOT}/${SERVER_LOG}"
    echo "接口日志: tail -f ${INSTALL_ROOT}/${ACCESS_LOG}"
  else
    echo "启动失败，请查看: ${INSTALL_ROOT}/${SERVER_LOG}"
    exit 1
  fi
}

if is_configured; then
  echo ">> 检测到已安装，直接启动"
  start_server
else
  first_install
  start_server
fi
